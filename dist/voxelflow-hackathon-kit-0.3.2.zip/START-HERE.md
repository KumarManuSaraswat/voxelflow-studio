VoxelFlow Studio desktop beta

Read plugins/voxelflow-studio/INSTALL.md to install. This is a local desktop plugin, not a public ChatGPT directory listing.
