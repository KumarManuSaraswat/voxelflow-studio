@echo off
node "%~dp0doctor.mjs" --root "%~dp0."
echo.
pause
