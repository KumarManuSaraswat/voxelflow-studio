import { readFile, readdir, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { zipSync, unzipSync } from 'fflate';

// Explicit allowlist: never package local session tokens, research, or dependencies.
const files = {};
async function include(path) {
  const entries = await readdir(path, { withFileTypes: true });
  for (const entry of entries) {
    const child = `${path}/${entry.name}`;
    if (entry.isDirectory()) await include(child);
    else if (entry.isFile()) files[child] = new Uint8Array(await readFile(child));
  }
}
for (const path of ['packages', 'scripts', 'tests', 'docs', 'examples', 'plugins', 'distribution', '.github']) await include(path);
for (const path of ['.agents/plugins/marketplace.json']) files[path]=new Uint8Array(await readFile(path));
for (const path of ['README.md', 'CONTRIBUTING.md', 'GOVERNANCE.md', 'CODE_OF_CONDUCT.md', 'SECURITY.md', 'SUPPORT.md', 'CHANGELOG.md', 'LICENSE', 'THIRD_PARTY_NOTICES.txt', '.gitignore', '.gitattributes', 'package.json', 'package-lock.json', 'tsconfig.json', 'vitest.config.ts', 'dist/voxelflow_studio.js', 'dist/atlas_robot_bedrock_assets.zip', 'dist/atlas_robot_live_bedrock_assets.zip', 'dist/adventurer_bag_bedrock_assets.zip','dist/arcane_staff_bedrock_assets.zip','dist/adventurer_bag_live_bedrock_assets.zip']) {
  files[path] = new Uint8Array(await readFile(path));
}
await mkdir('dist', { recursive: true });
files['dist/brass_festival_lantern_bedrock_assets.zip']=new Uint8Array(await readFile('dist/brass_festival_lantern_bedrock_assets.zip'));
const version=JSON.parse(await readFile('package.json','utf8')).version;
const archive = `dist/voxelflow-studio-${version}.zip`;
const zipped = zipSync(files, { level: 6 });
const extracted = unzipSync(zipped);
if (Object.keys(extracted).length !== Object.keys(files).length) throw new Error('Release archive is incomplete.');
for (const [path, bytes] of Object.entries(files)) {
  if (!Buffer.from(extracted[path]).equals(Buffer.from(bytes))) throw new Error(`Archive mismatch: ${path}`);
}
await writeFile(archive, zipped);
const artifacts = [archive, 'dist/voxelflow_studio.js', 'dist/atlas_robot_bedrock_assets.zip', 'dist/atlas_robot_live_bedrock_assets.zip','dist/adventurer_bag_bedrock_assets.zip','dist/arcane_staff_bedrock_assets.zip','dist/adventurer_bag_live_bedrock_assets.zip'];
const hashes = [];
artifacts.push('dist/brass_festival_lantern_bedrock_assets.zip');
for (const path of artifacts) hashes.push(`${createHash('sha256').update(await readFile(path)).digest('hex')}  ${path.split('/').at(-1)}`);
await writeFile('dist/SHA256SUMS.txt', hashes.join('\n') + '\n');
console.log(`Release verified: ${Object.keys(files).length} files, ${zipped.length} bytes. ${archive}`);
