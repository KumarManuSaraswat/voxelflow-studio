# Start here: VoxelFlow Studio

1. Read plugins/voxelflow-studio/INSTALL.md. Install Node.js 22+ and Blockbench desktop 5.2+ first.
2. Load plugins/voxelflow-studio/blockbench/voxelflow_studio.js in Blockbench (File > Plugins > Load Plugin from File).
3. Windows: double-click Start VoxelFlow.cmd in THIS folder, then connect in Blockbench (Tools > VoxelFlow Studio > Connect).
4. Install VoxelFlow in a supported LOCAL desktop chat host. A cloud chat or plugin mention alone cannot access your laptop.
5. Run Check VoxelFlow.cmd if setup fails. It checks local tools and the editor, not chat permissions.
6. Try the prompts in plugins/voxelflow-studio/PROMPTS.md. Review and approve changes in Blockbench.

No AI account? The Bag, Staff and Robot examples in Blockbench work offline.

This is an early desktop beta, not a public ChatGPT directory listing.
