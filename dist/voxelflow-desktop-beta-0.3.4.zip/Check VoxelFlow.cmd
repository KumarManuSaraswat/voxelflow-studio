@echo off
call "%~dp0plugins\voxelflow-studio\Check VoxelFlow.cmd"
