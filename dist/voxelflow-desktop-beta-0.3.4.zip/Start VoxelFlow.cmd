@echo off
call "%~dp0plugins\voxelflow-studio\Start VoxelFlow.cmd"
